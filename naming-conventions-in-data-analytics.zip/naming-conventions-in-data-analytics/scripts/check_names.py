"""
check_names.py - checks file and folder names in a project against the
naming standards in docs/naming-standards.md.

Usage:
    python scripts/check_names.py <folder>

Example:
    python scripts/check_names.py examples/messy-project

Exit code is 0 when every name passes and 1 when any name breaks a rule,
so the script can also run as an automated check.
"""

import re
import sys
from datetime import datetime
from pathlib import Path

# Files and folders that follow their own established conventions.
IGNORED = {".git", ".gitkeep", ".gitignore", "README.md", "LICENSE", "__pycache__"}

# Words that say nothing about the content or version of a file.
VAGUE_WORDS = {"final", "new", "copy", "untitled", "latest", "temp", "test", "misc", "stuff"}

# Generic stems that describe nothing on their own.
GENERIC_STEMS = {"data", "clean", "query", "file", "output", "dashboard", "report", "sheet"}

FILE_CHARS = re.compile(r"^[a-z0-9_.]+$")
FOLDER_PATTERN = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$|^[a-z0-9]+(_[a-z0-9]+)*$")
DATE_IN_NAME = re.compile(r"(?<!\d)(\d{8})(?!\d)")
NUMBERED_SCRIPT = re.compile(r"^\d{2}_[a-z0-9_]+\.(sql|py|ipynb)$")


def check_folder(name):
    problems = []
    if " " in name:
        problems.append("contains spaces")
    if name != name.lower():
        problems.append("uses capital letters")
    if not problems and not FOLDER_PATTERN.match(name):
        problems.append("use lowercase words joined by - or _")
    return problems


def check_file(path):
    name = path.name
    stem = path.stem.lower()
    problems = []

    if " " in name:
        problems.append("contains spaces")
    if name != name.lower():
        problems.append("uses capital letters")
    if re.search(r"\(\d+\)", name):
        problems.append("has a duplicate marker like (1)")
    if not FILE_CHARS.match(name.lower().replace(" ", "")) and "(" not in name:
        problems.append("has special characters")

    words = set(re.split(r"[_\s.\-()]+", stem))
    vague = sorted(words & VAGUE_WORDS)
    if vague:
        problems.append("vague word(s): " + ", ".join(vague))

    core = re.sub(r"\d+", "", stem).strip("_ ")
    if core in GENERIC_STEMS or len(stem) < 4:
        problems.append("name doesn't describe the content")

    for match in DATE_IN_NAME.findall(name):
        try:
            datetime.strptime(match, "%Y%m%d")
        except ValueError:
            problems.append(f"{match} isn't a valid YYYYMMDD date")

    if path.suffix in {".sql", ".py", ".ipynb"} and path.parent.name in {"sql", "scripts", "notebooks"}:
        if not NUMBERED_SCRIPT.match(name.lower()):
            problems.append("scripts should start with a run-order number, e.g. 01_")

    data_folder = any(k in part.lower() for part in path.parts[:-1] for k in ("data", "raw", "clean"))
    if path.suffix in {".csv", ".xlsx", ".xls"} and data_folder:
        if not DATE_IN_NAME.search(name):
            problems.append("data files should include a YYYYMMDD date")
        if not re.search(r"_v\d{2}(?=\.)", name.lower()):
            problems.append("data files should end with a version like _v01")

    return problems


def scan(root):
    results = []
    for path in sorted(root.rglob("*")):
        if any(part in IGNORED for part in path.relative_to(root).parts):
            continue
        problems = check_folder(path.name) if path.is_dir() else check_file(path)
        results.append((path.relative_to(root), path.is_dir(), problems))
    return results


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)

    root = Path(sys.argv[1])
    if not root.is_dir():
        print(f"Folder not found: {root}")
        sys.exit(2)

    results = scan(root)
    failures = [r for r in results if r[2]]

    for rel, is_dir, problems in results:
        label = "DIR " if is_dir else "FILE"
        if problems:
            print(f"  FAIL  {label}  {rel}")
            for p in problems:
                print(f"               - {p}")
        else:
            print(f"  PASS  {label}  {rel}")

    print(f"\n{len(results) - len(failures)} of {len(results)} names pass.")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
