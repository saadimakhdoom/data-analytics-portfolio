# Naming Conventions in Data Analytics

A practical guide to naming files, folders, tables, columns and measures across Excel, Power BI, SQL and Python, and why those decisions belong in the planning stage of every data project. It includes a Python script that checks a project folder against the standards automatically.

**Tools:** Python, Markdown, Git
**Skills shown:** project planning, documentation, data governance, Python scripting

---

## Why this project exists

The first hour of most analysis isn't spent analysing. It's spent working out which file is the latest one, what `data2.csv` contains, and whether `Employee Data FINAL.xlsx` is newer than `employee data (1).csv`.

Poor naming causes real problems in data work:

- **Wrong data gets analysed.** Two files called `final` and nobody knows which one the dashboard is built on.
- **Code breaks.** Spaces and capitals in names cause errors in SQL, Python and file paths, and links on GitHub break too.
- **Work can't be repeated.** If scripts aren't numbered, nobody can rerun the cleaning steps in the right order.
- **Handovers fail.** A colleague, a manager or a recruiter opening the project can't follow it.

Good names cost nothing to apply on day one and a lot to fix later. That's why this guide treats naming as part of project planning, not tidying up at the end.

## Where naming fits in the data analysis process

This follows the six phases taught in the Google Data Analytics Certificate:

| Phase | Naming decisions made at this stage |
|---|---|
| **Ask** | Project name, folder name |
| **Prepare** | Folder structure, raw data file names, data dictionary |
| **Process** | Column names, cleaned file versions, cleaning log |
| **Analyse** | Script and notebook order, measure and calculated column names |
| **Share** | Chart titles, image file names, dashboard labels |
| **Act** | Final README and output files |

Most naming decisions are made in **Ask** and **Prepare**, before any analysis starts. That's the point: setting the rules early saves rework at every later stage.

## The standard in brief

| What | Pattern | Example |
|---|---|---|
| Folders | lowercase, hyphenated | `workforce-analytics/` |
| Data files | `subject_detail_stage_YYYYMMDD_vNN` | `workforce_employees_raw_20261118_v01.csv` |
| Excel sheets | numbered by stage | `01_Raw_Data`, `04_Dashboard` |
| Power BI tables | `Fact_` and `Dim_` prefixes | `Fact_Shifts`, `Dim_Employee` |
| Power BI measures | plain English | `Absence Rate %` |
| SQL tables and columns | snake_case | `shift_records.hire_date` |
| Scripts and notebooks | run-order number + purpose | `02_data_cleaning.sql` |

The full rules for each tool are in [`docs/naming-standards.md`](docs/naming-standards.md).

## Before and after

The same project, named two ways.

**Before** (`examples/messy-project`)
```
Raw Data/
    Employee Data FINAL.xlsx
    employee data (1).csv
    Copy of shifts_new.xlsx
cleaned/
    clean.csv
    data2.csv
query.sql
Dashboard v3 FINAL final.pbix
Untitled.ipynb
```

**After** (`examples/clean-project`)
```
data/
    raw/
        workforce_employees_raw_20261118_v01.csv
        workforce_shifts_raw_20261118_v01.xlsx
    cleaned/
        workforce_employees_clean_20261120_v02.csv
sql/
    01_data_exploration.sql
    02_data_cleaning.sql
    03_analysis_absence_rates.sql
images/
    dashboard_overview.png
docs/
    cleaning_log.md
```

In the second version you can tell what each file holds, when it was made, which version it is and what order the scripts run in, without opening anything.

## The name checker

`scripts/check_names.py` scans a project folder and reports every name that breaks the standards: spaces, capitals, vague words like `final` or `copy`, duplicate markers like `(1)`, invalid dates, missing versions on data files and unnumbered scripts.

**Run it** (Python 3, no extra packages needed):
```bash
python scripts/check_names.py examples/messy-project
```

**Output on the messy example:**
```
  FAIL  FILE  Raw Data/Employee Data FINAL.xlsx
               - contains spaces
               - uses capital letters
               - vague word(s): final
               - data files should include a YYYYMMDD date
               - data files should end with a version like _v01
  FAIL  FILE  cleaned/data2.csv
               - name doesn't describe the content
  ...
1 of 10 names pass.
```

**Output on the clean example:**
```
14 of 14 names pass.
```

The script exits with code `1` when any name fails, so it can also run as an automatic check before files are committed.

## How to use this in a new project

1. Copy `templates/project-folder-template/` and rename it for the project.
2. Work through [`docs/project-planning-checklist.md`](docs/project-planning-checklist.md) before opening the data.
3. Name everything using [`docs/naming-standards.md`](docs/naming-standards.md).
4. Run the checker before uploading to GitHub.

## Repository structure
```
naming-conventions-in-data-analytics/
├── README.md
├── docs/
│   ├── naming-standards.md            full rules for each tool
│   └── project-planning-checklist.md  checklist for each phase
├── scripts/
│   └── check_names.py                 automated name checker
├── examples/
│   ├── messy-project/                 poorly named example
│   └── clean-project/                 same project, named to the standard
└── templates/
    └── project-folder-template/       empty starter structure
```

## About me
Saadi (Mujtaba Makhdoom) · [LinkedIn](https://www.linkedin.com/in/YOUR-LINKEDIN) · [Portfolio](https://github.com/YOUR-USERNAME)
