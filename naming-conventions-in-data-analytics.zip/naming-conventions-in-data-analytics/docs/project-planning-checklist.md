# Project Planning Checklist

Use this before touching any data. Naming decisions belong at the start of a project, not the end, because renaming files halfway through breaks formulas, queries, Power BI connections and links in the README.

## Ask
- [ ] Problem statement written in one or two sentences
- [ ] Stakeholders listed
- [ ] Three to five key questions the analysis must answer
- [ ] Project name chosen (lowercase, hyphenated, describes the subject): `workforce-analytics`

## Prepare
- [ ] Project folder created from `templates/project-folder-template`
- [ ] Raw data saved to `data/raw/` using the data file pattern
- [ ] Raw files set to read-only, or a note made never to edit them
- [ ] Data source, licence and date recorded in the README
- [ ] Data dictionary started in `docs/`

## Process
- [ ] Cleaning log started in `docs/`
- [ ] Column names standardised (snake_case in SQL and Python, readable names in Power BI)
- [ ] Cleaned output saved to `data/cleaned/` with a new version number
- [ ] Every cleaning step recorded so it can be repeated

## Analyse
- [ ] Scripts, notebooks or sheets numbered in run order
- [ ] Measures and calculated columns named in plain English
- [ ] Validation checks saved alongside the analysis

## Share
- [ ] Dashboard and chart images saved to `images/` with descriptive names
- [ ] Visual titles and measure names make sense to someone outside the project

## Act
- [ ] Recommendations linked to specific findings
- [ ] README updated with the final story
- [ ] `python scripts/check_names.py <project-folder>` run, and every name passes
