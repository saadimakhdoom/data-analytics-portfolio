# Naming Standards

These are the rules used across every project in this portfolio. Each section covers one tool, because Excel, Power BI, SQL and Python each have their own habits, but the same three ideas sit underneath all of them:

1. **Describe the content.** Someone who has never seen the project should be able to guess what a file holds from its name alone.
2. **Be consistent.** Pick one pattern and use it everywhere. A consistent but imperfect rule beats a perfect rule used half the time.
3. **Make names sort and search well.** Dates go year first, scripts are numbered in run order, and names avoid spaces and special characters that break code and links.

---

## 1. Folders

| Rule | Good | Avoid |
|---|---|---|
| Lowercase, words joined with `-` or `_` | `workforce-analytics`, `data/raw` | `Workforce Analytics`, `Raw Data` |
| Separate raw and cleaned data | `data/raw/`, `data/cleaned/` | one `data/` folder with everything mixed |
| Short and stable | `images/`, `docs/` | `screenshots for dashboard 2026/` |

**Standard project layout**
```
project-name/
├── README.md
├── data/
│   ├── raw/        never edited, kept exactly as received
│   └── cleaned/    output of the cleaning step
├── sql/ or notebooks/ or workbook/ or report/
├── images/
├── docs/
└── outputs/        exported results, charts, summary tables
```

## 2. Data files

**Pattern:** `subject_detail_stage_YYYYMMDD_vNN.ext`

| Part | Meaning | Example |
|---|---|---|
| subject | what the data is about | `workforce` |
| detail | which slice of it | `employees`, `shifts` |
| stage | raw, clean, analysis, output | `raw` |
| YYYYMMDD | date the file was created or extracted | `20261118` |
| vNN | two-digit version | `v01` |

**Examples**
- `workforce_employees_raw_20261118_v01.csv`
- `workforce_employees_clean_20261120_v02.csv`
- `workforce_absence_summary_20261121_v01.xlsx`

**Why the date is YYYYMMDD:** it sorts in date order automatically and means the same thing in Ireland, the US and everywhere else. `11-12-2026` could be November or December depending on who reads it.

**Why `v01` instead of `final`:** there is never only one final version. `v01`, `v02`, `v03` sorts correctly and shows the history.

## 3. Excel

| Element | Rule | Example |
|---|---|---|
| Workbook | follows the data file pattern | `workforce_management_analysis_20261118_v01.xlsx` |
| Sheets | number by stage, short and clear | `01_Raw_Data`, `02_Clean_Data`, `03_Analysis`, `04_Dashboard` |
| Excel tables | `tbl` prefix, no spaces | `tblEmployees`, `tblShifts` |
| Named ranges | `rng` prefix | `rngTargetHours` |
| Helper columns | say what they calculate | `Tenure_Years`, `Is_Overtime` |

Numbering the sheets keeps them in process order and lets a reviewer follow the work from raw data to dashboard, left to right.

## 4. Power BI

| Element | Rule | Example |
|---|---|---|
| Report file | follows the data file pattern | `workforce_dashboard_20261118_v01.pbix` |
| Fact tables | `Fact_` prefix | `Fact_Shifts`, `Fact_Absences` |
| Dimension tables | `Dim_` prefix | `Dim_Employee`, `Dim_Date`, `Dim_Department` |
| Measures table | one table holding all measures | `_Measures` |
| Measures | plain English, readable on a visual | `Total Headcount`, `Absence Rate %`, `Avg Hours per Employee` |
| Columns | match the source, then rename for readers | `employee_id` → `Employee ID` |

Measure names appear on the dashboard itself, so they are written for the audience, not for the developer.

## 5. SQL

| Element | Rule | Example |
|---|---|---|
| Tables | snake_case, plural nouns | `employees`, `shift_records` |
| Columns | snake_case, singular | `employee_id`, `hire_date`, `hourly_rate` |
| Primary keys | `table_id` | `employee_id` |
| Booleans | `is_` or `has_` prefix | `is_active`, `has_overtime` |
| Dates | end in `_date` or `_at` | `hire_date`, `created_at` |
| Script files | run-order number + purpose | `01_data_exploration.sql`, `02_data_cleaning.sql`, `03_analysis_absence_rates.sql` |
| Aliases | short but meaningful | `e` for employees is fine in a join; `t1`, `t2` is not |
| Keywords | UPPERCASE | `SELECT`, `FROM`, `WHERE` |

## 6. Python

| Element | Rule | Example |
|---|---|---|
| Notebooks | run-order number + purpose | `01_data_cleaning.ipynb`, `02_eda.ipynb` |
| Scripts | snake_case | `check_names.py` |
| Variables | snake_case, descriptive | `clean_employees`, `absence_rate` |
| DataFrames | `df_` + content | `df_shifts`, `df_absence_summary` |
| Functions | verb first | `load_data()`, `calculate_tenure()` |
| Constants | UPPERCASE | `TARGET_HOURS = 37.5` |

## 7. Words to never use in a name

`final`, `new`, `latest`, `copy`, `untitled`, `temp`, `test`, `misc`, `stuff`, `(1)`

Each of these says something about the moment the file was saved, not about what is inside it, and every one stops being true almost immediately.
